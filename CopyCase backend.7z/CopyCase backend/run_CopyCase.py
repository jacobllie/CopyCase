import sys
import os

#PATH = "I:\\STOLAV - Kreftklinikken\\Avdelinger kreft\\Avdeling for stråleterapi\\Fysikere\\Jacob\\CopyCase"
PATH = "H:/dokumenter/Github/CopyCase/CopyCase backend"
sys.path.append(PATH)

import CopyCase as copycase

copycase.copycase()
